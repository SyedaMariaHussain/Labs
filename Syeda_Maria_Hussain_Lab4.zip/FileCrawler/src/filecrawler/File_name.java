/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filecrawler;
import java.io.*;     
import java.util.*; 
/**
 *
 * @author shussain.bscs13seecs
 */

//A class for getting the file path or name or string from the user..
public class File_name {
    	public String _fname;
	public String _fpath;
	public String _fstring;
    
}
