/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filecrawler;
import java.io.*;     
import java.util.*;
/**
 *
 * @author shussain.bscs13seecs
 */

//Class for the strings that needs to bhi searched.
public class Index_name {
    		public int _fsize;
		public String _fname;
		public String _fpath;
    
}
