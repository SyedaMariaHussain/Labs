/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.Serializable;

/**
 *
 * @author shussain.bscs13seecs
*/
class testobject implements Serializable {
    int choice;
String description ;
String username;
public  testobject(int c,String v, String s ){
this.choice = c; 
this.description=s;
this.username=v;
}
}

