/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import static java.lang.System.in;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


/**
 *
 * @author shussain.bscs13seecs
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    
    private static Socket socket;
    public static void main(String[] args) {
        
        // TODO code application logic here
        
     try{
         String username;
         String description;
         int choice;
Socket s = new Socket("localhost",2002);
OutputStream os = s.getOutputStream();
ObjectOutputStream oos = new ObjectOutputStream(os);
Scanner in = new Scanner(System.in);
 
      System.out.println("Enter username: ");
      username = in.nextLine();
      System.out.println("You entered string "+username);
      System.out.println("Enter descritption: ");
      description = in.nextLine();
      System.out.println("You entered string "+description);
       System.out.println("Enter 1 for writing data and 2 for accessing data: ");
      choice = in.nextInt();
      while(choice > 2 && choice <1 )
      {
          System.out.println("Invalid Input ");
           choice = in.nextInt();
      }
      
          
      System.out.println("You entered integer "+choice );
      
        testobject to = new testobject(choice,username,description);

oos.writeObject(to);
oos.close();
os.close();
s.close();
}catch(Exception e){System.out.println(e);}
}
        
        
       
    }
        
        
        
        
        
        
        


