/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

/**
 *
 * @author shussain.bscs13seecs
 */


class testobject implements Serializable {
String description ;
String username;
int choice;
public  testobject(int c,String v, String s ){
this.description=s;
this.username=v;
this.choice = c; 
}
}





public class Server extends Thread{

    /**
     * @param args the command line arguments
     */
    

   
  
     
    public static void main(String[] args) {
        // TODO code application logic here
         int port = 2002;
try {
    while(true)
    {
ServerSocket ss = new ServerSocket(port);
Socket s = ss.accept();
InputStream is = s.getInputStream();
ObjectInputStream ois = new ObjectInputStream(is);
testobject to = (testobject)ois.readObject();
if (to!=null)
{
 if(to.choice == 1)
 { System.out.println(to.username);
    System.out.println((String)ois.readObject());
    PrintWriter writer = new PrintWriter(to.username, "UTF-8");
    writer.println(to.description);
writer.close();
is.close();
s.close();
ss.close();
 }
if(to.choice == 2)
{
     System.out.println("Opening the file for the user.")
}
}

}
}catch(Exception e){System.out.println(e);}
}
}
        
        
        
    

    

