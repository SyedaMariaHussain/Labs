
#ifndef INFORMATION_H
#define INFORMATION_H
# include<iostream>
# include "snakes_ladder.h"
#include<stdlib.h>
#include<string>


class Info
{
public:
	Info();
	~Info();

	int max_rounds(int rounds);// function for max number of rounds.
	int min_rounds(int rounds);// function for minimum number of rounds.
	int sum_ave(int rounds); // function for summing all rounds.
	int average_cal();// function for calculating average number of rounds to complete the game.
	void setMIN(int rounds);
	int max_No_round;
	int min_No_rounds;
	int average;

};


#endif