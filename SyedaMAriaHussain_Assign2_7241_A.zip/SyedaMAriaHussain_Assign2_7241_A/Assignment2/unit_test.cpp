#include<iostream>
# include "snakes_ladder.h"
#include "unit_test.h"
#include<stdlib.h>
#include<time.h>
#include<string>
# include <map>


snake_unit_test::snake_unit_test()
{
}

snake_unit_test::~snake_unit_test()
{
}
// 
void snake_unit_test::dice_check()
{
	int dice_check = 0;
	dice_check = test.roll_dice();
	if (dice_check <= 6 && dice_check > 0)
		cout << "Test Successful" << endl;
	else
		cout << "Test Unsuccessful" << endl;

}

// Test for checking snakes head.
void snake_unit_test::snake_pos_check(int pos)
{
	test.score = pos;
	cout << "Snake Head Test" << endl;
	if ((test.check_Snake_head()) == 1)
		cout << "Test Successful" << endl;
	else
		cout << "Test Unsuccessful " << endl;


}

// Test for checking ladders bottom
void snake_unit_test::ladder_pos_check(int pos)
{
	test.score = pos;
	cout << "Ladder Bottom Test" << endl;
	if ((test.check_ladder_end()) == 1)
		cout << "Test Successful" << endl;
	else
		cout << "Test Unsuccessful " << endl;


}

