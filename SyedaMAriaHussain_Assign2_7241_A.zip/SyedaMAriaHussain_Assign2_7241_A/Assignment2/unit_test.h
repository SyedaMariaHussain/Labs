#ifndef UNIT_TEST_H
#define UNIT_TEST_H
#include<iostream>
#include<stdlib.h>
using namespace std;

class snake_unit_test
{
public:
	snake_unit_test();
	~snake_unit_test();
	// testing dice
	void dice_check();
	void snake_pos_check(int pos);
	void ladder_pos_check(int pos);

	Snakes_And_Ladders  test;


};




#endif