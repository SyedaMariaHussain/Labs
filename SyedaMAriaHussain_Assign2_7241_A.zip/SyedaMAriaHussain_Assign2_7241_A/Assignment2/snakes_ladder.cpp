#include<iostream>
# include "snakes_ladder.h"
#include<stdlib.h>
#include<time.h>
#include<string>
# include <map>




Snakes_And_Ladders::Snakes_And_Ladders()
{
	score = 0;
	wins = 0;
}

Snakes_And_Ladders::~Snakes_And_Ladders()
{
}
int Snakes_And_Ladders::getScore()
{
	return score;
}


// ************ FUNCTION FOR CREATING BOARD *****************//
void Snakes_And_Ladders::Draw_Board()
{
	// Board Creation
	int box_num = 1;
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			Board[i][j] = box_num ++ ;  
		}
	}

	// Setting the snakes in the boards.
	Snakes[17] = 10;
	Snakes[62] = 43;
	Snakes[54] = 20;
	Snakes[64] = 4;
	Snakes[87] = 39;
	Snakes[95] = 20;
	Snakes[93] = 20;
	Snakes[97] = 20;
	// Setting the ladders in the board.
	Ladders[1] = 38 ;
	Ladders[4] = 10 ;
	Ladders[9] = 27 ;
	Ladders[28] = 55;
	Ladders[21] = 21;
	Ladders[51] = 16;
	Ladders[71] = 20;
	Ladders[80] = 20;
}

/************************* DICE ROLL FOR THE PLAYERS *******************************/

void Snakes_And_Ladders::game_play()
{

	int dice = 0;
	dice = roll_dice();
	score = score + dice;


	// Check for snake Head....
	
	check_Snake_head();

	// Check for ladders....
	check_ladder_end();

	// checking winner...
	if (check_win() == 1)
		wins = 1;
	//cout << "Score : " << score << endl;
}

// Snakes head check...
int Snakes_And_Ladders::check_Snake_head()
{
	int snake_head = 0;
	std::map<int, int>::iterator it;
	if (Snakes.find(score) == Snakes.end()) {
		// do nothing
		return 0;
	}
	else {

		cout << score << endl;
		cout << "Snake Bite !!!" << endl;
		snake_head = Snakes[score];
		score = score - snake_head;
		return 1;

	}

}

// function for rolling the dice.

int Snakes_And_Ladders::roll_dice()

{
	int dice = 0;
	int Score = 0;
	// Rolling the dice.....
	dice = ((rand() % 6) + 1);
	score = score + dice;
	srand(time(NULL));
	// The condition for if the dice gives 6.
	if (dice == 6)
	{
		do
		{

			cout << "A SIX ! Lucky Day. " << endl;
			dice = ((rand() % 6) + 1);
			Score = Score + dice;

		} while (dice == 6);
	}


	return Score;

}


// Function for checking ladders....

int Snakes_And_Ladders::check_ladder_end()
{
	int ladder = 0;
	std::map<int, int>::iterator it;
	if (Ladders.find(score) == Ladders.end()) {
		// do nothing
		return 0;
	}
	else {

		cout << score << endl;
		cout << "Going Up the ladder !!!" << endl;
		ladder = Ladders[score];
		score = score + ladder;
		return 1;

	}

}

// Condition check for winning...
bool Snakes_And_Ladders::check_win()
{
	if (score >= 100)
		return 1;
	else
		return 0;

}

int Snakes_And_Ladders::getWin()
{
	return wins;
}


