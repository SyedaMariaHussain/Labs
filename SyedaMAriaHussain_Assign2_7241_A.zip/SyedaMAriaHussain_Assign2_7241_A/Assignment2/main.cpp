# include<iostream>
# include "snakes_ladder.h"
# include "information.h"
# include "unit_test.h"
#include<stdlib.h>
#include<string>
#include<time.h>
#include<math.h>

using namespace std;
int main()
{
	snake_unit_test test;
	int max = 0;
	int check = 1;
	Info information;
	int score = 0;
	int option = 0;
	int turn = 1;
	int winners = 0;
	int rounds = 0;

	for (int i = 0; i < 100; i++)

	{


		cout << "------------------------------------------------------------------------------------------------------- " << endl;
		cout << "************************************ WELCOME TO SNAKES AND LADDERS ************************************ " << endl;
		cout << "------------------------------------------------------------------------------------------------------- " << endl;
		cout << "Choose the number of Players: " << endl;
		cout << " 1- 2 Players \n 2- 4 Players " << endl;

		srand(time(NULL));
		option = ((rand() % 2) + 1);
		cout << option;
		// Switch statement for running the required condition.

		switch (option)

		{

			/*********************************FOUR TWO PLAYERS ********************************************************/
		case 1:
		{
				  cout << "You have Choosen 2 Players Game." << endl;

				 // cout << "Issue Here" << endl;
				  Snakes_And_Ladders Player1;
				  Snakes_And_Ladders Player2;
				  Player1.Draw_Board();
				  Player2.Draw_Board();
				  while (true)
				  {
					  cout << "here "<<endl;
					  // Player 1 turn ...
					  if (turn == 1)
					  {
						  

						
						  Player1.game_play();
						  turn = turn + 1;
						  if (winners != 1)
							  winners = Player1.getWin();
						  else
						  {
							  cout << "Player 2" << " Won !!!" << endl;
							  cout << "Game Over" << endl;
							  check = 1;
							  turn = 1;
							  winners = 0;
							  
							  
							  information.max_rounds(rounds);
							  information.min_rounds(rounds);
							  information.sum_ave(rounds);
							  rounds = 0;
							  break;
						  }
					  }

					  // Player 2 turn ...
					  else if (turn == 2)
					  {
						  cout << "Player " << turn << "'s turn" << endl;
						  cout << "Previous Score:" << Player2.getScore() << endl;

						  Player2.game_play();
						  cout << "New Score:" << Player2.getScore() << endl;
						  turn = turn - 1;
						  if (winners != 1)
							  winners = Player2.getWin();
						  else
						  {
							  
							  cout << "Player 1" << " Won !!!" << endl;
							  cout << " Game Over" << endl;
							  turn = 1;
							 
							  information.max_rounds(rounds);
							  information.min_rounds(rounds);
							  information.sum_ave(rounds);
							  rounds = 0;
							  winners = 0;
							  break;
						  }

					  }

					  rounds++;
					 
				  }
		}
			break;

			/***************************FOR FOUR PLAYERS**********************************/
		case 2:
		{

				  winners = 0;
				  cout << "You have Choosen 4 Players Game. " << endl;
				  Snakes_And_Ladders Player1;
				  Snakes_And_Ladders Player2;
				  Snakes_And_Ladders Player3;
				  Snakes_And_Ladders Player4;
				  Player1.Draw_Board();
				  Player2.Draw_Board();
				  while (true)
				  {

					  
					  // Player 1 turn..
					  if (turn == 1)
					  {
						 

						  Player1.game_play();
						  
						  turn = turn + 1;
						  if (winners != 1)
							  winners = Player1.getWin();
						  else
						  {
							  cout << "Player 4" << " Won !!!" << endl;
							  winners = 0;
							  cout << "Game Over" << endl;
							
							 
							  if (max < rounds)
								  max = rounds;
							  information.max_rounds(rounds);
							  information.min_rounds(rounds);
							  information.sum_ave(rounds);
							  rounds = 0;
							  turn = 1;
							  break;
						  }
					  }

					  // Player 2 turn..
					  else if (turn == 2)
					  {

						  Player2.game_play();
						  turn = turn + 1;
						  if (winners != 1)
							  winners = Player2.getWin();
						  else
						  {
							  
							  cout << "Player 1" << " Won !!!" << endl;
							  cout << " Game Over" << endl;
							 
							  information.max_rounds(rounds);
							  information.min_rounds(rounds);
							  information.sum_ave(rounds);
							  rounds = 0;
							  winners = 0;
							  turn = 1;
							  break;
						  }


					  }

					  // Player 3 turn..
					  else if (turn == 3)
					  {

						  Player3.game_play();
						  turn = turn + 1;
						  if (winners != 1)
							  winners = Player3.getWin();
						  else
						  {
							  check = 1;
							  cout << "Player 2" << " Won !!!" << endl;
							  cout << " Game Over" << endl;
							 
							  information.max_rounds(rounds);
							  information.min_rounds(rounds);
							  information.sum_ave(rounds);
							  rounds = 0;
							  winners = 0;
							  turn = 1;
							  break;
						  }


					  }

					  // Player 4 turn..

					  else if (turn == 4)
					  {
						  Player4.game_play();
						  cout << "New Score:" << Player4.getScore() << endl;
						  turn = turn - 3;
						  if (winners != 1)
							  winners = Player4.getWin();
						  else
						  {
							  check = 1;
							  cout << "Player 3" << " Won !!!" << endl;
							  cout << " Game Over" << endl;
							
							  information.max_rounds(rounds);
							  information.min_rounds(rounds);
							  information.sum_ave(rounds);
							  rounds = 0;
							  winners = 0;
							  turn = 1;
							  break;
						  }

					  }

					  rounds++;
					  

				  }

		}
		default:
			break;
		}

		
	}

	
	cout << "*************************GAME ANALYSIS****************************************" << endl;
	cout << "Max Number of rounds to complete the game :" << information.max_No_round << endl;
	cout << "Min Number of rounds to complete the game :" << information.min_No_rounds << endl;
	cout << "Average Number of rounds to complete the game :" << information.average_cal() << endl;
	int s;
	// Unit tests
	cout << "Snake check :" << endl;
	test.snake_pos_check(5);
	cout << "Ladder check :" << endl;
	test.ladder_pos_check(45);
	cout <<"Test for dice :"<< test.dice_check << endl;
	



	system("pause");
	return 0;



}