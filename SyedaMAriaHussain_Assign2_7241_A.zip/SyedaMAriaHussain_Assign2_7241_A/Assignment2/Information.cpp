#include<iostream>
# include "information.h"
#include<stdlib.h>
#include<time.h>
#include<math.h>
#include<string>
# include <map>


int Info::max_rounds(int rounds)
{
	if (max_No_round < rounds)
		max_No_round = rounds;
	else
		return 0;
}

void Info::setMIN(int rounds)
{
	min_No_rounds = rounds;
}

int Info::min_rounds(int rounds)
{
	if (min_No_rounds > rounds)
		min_No_rounds = rounds;
	else
		return 0;
}

int Info::sum_ave(int rounds)
{
	average = average + rounds;
	return average;
}

int Info::average_cal()
{
	average = ceil(average / 100);
	return average;
}


Info::Info()
{
	max_No_round = 0;
	min_No_rounds = 1000;
	average = 0;

}

Info::~Info()
{
}

