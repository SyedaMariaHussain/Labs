#ifndef SNAKES_LADDER_H
#define SNAKES_LADDER_H
#include<iostream>
#include<stdlib.h>
#include<string>
# include <map>
using namespace std;
class Snakes_And_Ladders
{
public:
	Snakes_And_Ladders();
	~Snakes_And_Ladders();

	void Draw_Board();  //function for drawing the board.
	void game_play(); // for rolling the dice.
	int check_Snake_head(); // for checking the snakes head.
	int check_ladder_end(); // for checking the ladders bottom.
	bool check_win(); // function for checking the winner.
	int getWin(); // getting the winners value
	int getScore();
	int roll_dice();


	int Board[10][10];
	map <int, int> Snakes;
	map <int, int> Ladders;
	int score;
	int wins;

};













#endif