#ifndef COPIED_POINTER_H
#define	COPIED_POINTER_H



using namespace std;

class Copied_Pointer{

public:
	Copied_Pointer();//constructor
	~Copied_Pointer(); // destructor
	Copied_Pointer(const Copied_Pointer& other);
	Copied_Pointer(char* str, int n);
	char charAt(int) const;   //returns the character at the passed index
	int length() const; // Returns the length of _strbuf
	void reserve(int len); // Reserves memory
	void append(char app); // Appends a character.
	void print();
	Copied_Pointer& operator= (Copied_Pointer& other); // Operator overloading 



private:
	char* _strbuf;
	//char* _strbuf2;
	int _length;

};


#endif