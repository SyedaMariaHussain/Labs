#ifndef OWNED_POINTER_H
#define OWNED_POINTER_H

#include<iostream>
#include<string.h>
#include<stdio.h>


using namespace std;

class OwnedPointer{

public:
	OwnedPointer()
	{
	    owner = true;    
	}
	~OwnedPointer()
	{
	    
		delete[] _strbuf;
	
	   
	      
	    
	}

	OwnedPointer(const OwnedPointer& other)
	{
		int len = other._length;
		cout << len;
		_strbuf = new char[len];
		_strbuf = other._strbuf;
		owner = true;
		other.owner = false;
		_length = len;	
	}



	OwnedPointer(char* str, int n) 
	{
		_strbuf = new char[n];
		strcpy(_strbuf, str);
		owner = true;
		_length = n;

	}


	char charAt(int index) const   //returns the character at the passed index
	{
		int len = length();
	if (index > len)
	{
		cout << "The index is greater then the length" << endl;
	}
	else
	{
		return _strbuf[index];
	}
		
	}
	int length() const
	{
		return _length;

	}
	void reserve(int len)
	{
		_strbuf = new char[len];

	}

	void append(char app)
	{

		int len = length();
		
		_strbuf[len] = app;
		
		++_length;
		
	}

	void print()
	{
		int len = length();
		for (int i = 0; i < len+1; ++i)
		{
			cout <<	_strbuf[i];
		}
	}

OwnedPointer& operator= (const OwnedPointer& other)
{
    
     if(this->owner == true)
    {
        delete[] _strbuf;
        delete _strbuf;
        cout<<"It was the owner"<<endl;
    }
    
    else 
    {
        delete _strbuf;
        
    }
    
    _strbuf = new char[other._length];
    this->_strbuf = other._strbuf;

    this->_length = other._length;
   
	cout<<other.owner<<endl;
	other.owner = false;
	cout<< other.owner<<endl;
    return *this;
    
}


void checkowner()
{
    cout<<endl;
    if(owner == true)
    cout<< "It is the owner"<<endl;
    else
    cout<<"It is not the owner."<<endl;
}


private:
	char* _strbuf;
	char* _strbuf2;
	int _length;
	mutable bool owner;
};

#endif