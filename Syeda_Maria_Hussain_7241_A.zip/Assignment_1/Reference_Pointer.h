#ifndef REFERENCE_POINTER_H
#define REFERNCE_POINTER_H

class ReferencePointer{

public:
	ReferencePointer();
	
	~ReferencePointer();
	

	ReferencePointer(const ReferencePointer& other);
	



	ReferencePointer(char* str, int n);
	


	char charAt(int) const;   //returns the character at the passed index
	int length() const;
	
	void reserve(int len);
	

	void append(char app);
	

	void print();
	

	void check_count();
	

	ReferencePointer& operator= (const ReferencePointer& other);
	


	void checkowner();
	


private:
	struct c
	{
		c(int ce = 0)
		{
			count = ce;
		}
		int count;
	} *cptr;

	char* _strbuf;

	int _length;
	mutable bool owner;
};






#endif