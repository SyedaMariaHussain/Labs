#include<iostream>
#include<string.h>
#include<stdio.h>
#include "Reference_link.h"
#include "Reference_Pointer.h"
#include "Owned_Pointer.h"
#include "Copied_Pointer.h"
using namespace std;

int main()
{
	cout << "************* TASK 1: Copied Pointers ************************" << endl;
	Copied_Pointer* ptr1 = new Copied_Pointer();
	ptr1->reserve(10);
	ptr1->append('M');
	ptr1->append('A');
	Copied_Pointer* ptr2 = new Copied_Pointer();
	*ptr2 = *ptr1;
	ptr1->append('A');
	ptr1->print();
	ptr2->print();

	cout << endl;
	cout << "************* TASK 2 : Owned Pointers **************************" << endl;
	OwnedPointer* ptr3 = new  OwnedPointer();
	ptr3->reserve(3);
	ptr3->append('M');
	ptr3->append('A');
	OwnedPointer* ptr4 = new  OwnedPointer();
	*ptr4 = *ptr3;
	ptr3->append('A');
	ptr3->print();
	ptr4->print();

	cout << endl;
	cout << "************* TASK 3 : COW With Reference Counting **************************" << endl;
	ReferencePointer* ptr5 = new ReferencePointer();
	ptr5->reserve(3);

	ptr5->append('M');
	ptr5->append('A');
	
	ReferencePointer* ptr6 = new ReferencePointer();
	ReferencePointer* ptr7 = new ReferencePointer();
	

	*ptr7 = *ptr6;
	ptr6->append('A');
	cout << endl;
	ptr7->print();
	cout << endl;
	ptr6->print();

	cout << endl;
	cout << "************* TASK 4 : COW With Reference Linking **************************" << endl;
	Ref_link* ptr8 = new Ref_link();
	Ref_link* ptr9 = new Ref_link();
	*ptr9 = *ptr8;
	ptr9->reserve(3);
	ptr8->append('a');
	ptr8->print();
	ptr9->print();




	return 0;
}