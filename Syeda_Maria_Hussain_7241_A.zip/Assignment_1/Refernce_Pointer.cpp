#include<iostream>
#include<string.h>
#include<stdio.h>
#include "Reference_Pointer.h"
using namespace std;




ReferencePointer::ReferencePointer()
{
	owner = true;
	cptr = new c(1);
}
ReferencePointer::~ReferencePointer()
{

	delete[] _strbuf;


}

ReferencePointer::ReferencePointer(const ReferencePointer& other)
{
	int len = other._length;
	cout << len;
	_strbuf = new char[len];
	_strbuf = other._strbuf;
	owner = true;
	++cptr->count;
	cout << "Reference" << cptr->count << endl;
	other.owner = false;
	_length = len;
}



ReferencePointer::ReferencePointer(char* str, int n)
{
	delete[] _strbuf;
	_strbuf = new char[n];
	strncpy(_strbuf, str,n);
	owner = true;
	++cptr->count;

	_length = n;

}


char ReferencePointer::charAt(int index) const   //returns the character at the passed index
{
	int len = length();
	if (index > len)
	{
		cout << "The index is greater then the length" << endl;
	}
	else
	{
		return _strbuf[index];
	}


}
int ReferencePointer::length() const
{
	return _length;

}
void ReferencePointer::reserve(int len)
{
	_strbuf = new char[len];

}

void ReferencePointer:: append(char app)
{

	int len = length();
	if (cptr->count == 1)
	{


		_strbuf[len] = app;

		++_length;
	}
	else
	{
		--cptr->count;
		c* cptr = new c();
		char* temp = new char[len];

		strncpy(temp, _strbuf,  len);
		_strbuf = new char[len];
		strcpy_s(_strbuf, len,temp);
		_strbuf[len] = app;

		++_length;
		cptr->count = 1;
		delete[] temp;

	}

}

void ReferencePointer::print()
{
	int len = length();
	for (int i = 0; i < len + 1; ++i)
	{
		cout << _strbuf[i];
	}
}

void ReferencePointer::check_count()
{
	cout << endl << cptr->count;
}

ReferencePointer& ReferencePointer:: operator= (const ReferencePointer& other)
{

	if (this != &other)
	{
		if (cptr->count == 1)
		{
			delete[] _strbuf;

			cout << "It was the owner" << endl;


			_strbuf = new char[other._length];
			this->_strbuf = other._strbuf;

			this->_length = other._length;

			cout << other.owner << endl;
			other.owner = false;
			cout << other.owner << endl;
			other.cptr->count = ++cptr->count;





		}

		else
		{
			cptr->count--;
			_strbuf = new char[other._length];
			this->_strbuf = other._strbuf;

			this->_length = other._length;

			cout << other.owner << endl;
			other.owner = false;
			cout << other.owner << endl;
			other.cptr->count = ++cptr->count;

			cout << "Reference : " << cptr->count << endl;




		}


		return*this;


	}

}


void ReferencePointer:: checkowner()
{
	cout << endl;
	if (owner == true)
		cout << "It is the owner" << endl;
	else
		cout << "It is not the owner." << endl;
}
