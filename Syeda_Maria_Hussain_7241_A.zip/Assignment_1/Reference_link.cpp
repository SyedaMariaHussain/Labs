#include<iostream>
#include<string.h>
#include<stdio.h>
#include "Reference_link.h"
using namespace std;








Ref_link::Ref_link(const Ref_link& r)
{
	acquire(r);
	_length = r._length;



}

Ref_link::~Ref_link()
{
	
	del();

}

bool Ref_link::single()
{
	if (Prev == this && Next == this)
		return 1;
	else
		return 0;
}

Ref_link& Ref_link::operator= (const Ref_link &r)
{

	if (this != &r) {
		del();
		acquire(r);
	}
	return *this;
}



int Ref_link::length() const{
	return _length;
}


char Ref_link::charAt(int index) const
{
	return _strbuf[index];
}


void Ref_link::reserve(int index)
{
	_strbuf = new char[index];
}

void Ref_link::append(char letter)
{
	if (single())
	{
		cout << "Original Copy" << endl;
		_strbuf[_length] = letter;
		_length += 1;
	}
	else
	{
		cout << "New Copy" << endl;
		char* temp = new char[_length];
		strncpy(temp, _strbuf, _length);
		del();
		_strbuf = new char[_length];
		strncpy(_strbuf, temp, _length);
		_strbuf[_length] = letter;
		_length += 1;
		delete[] temp;
		Next = Prev = this;

	}

}

void Ref_link::print()
{

	for (int i = 0; i < _length + 1; ++i)
	{
		cout << *(_strbuf + i);
	}
}
