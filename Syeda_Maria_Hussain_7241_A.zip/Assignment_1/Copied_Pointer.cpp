#include<iostream>
#include<string.h>
#include<stdio.h>
#include "Copied_Pointer.h"

// Implemtation of functions of the class Copied_Pointer
using namespace std;



Copied_Pointer::Copied_Pointer()
{}

Copied_Pointer::~Copied_Pointer()
{
	delete[] _strbuf;
}

Copied_Pointer::Copied_Pointer(const Copied_Pointer& other)
{
	int len = other._length;
	cout << len;
	_strbuf = new char[10];

	char* ch = other._strbuf;

	strcpy_s(_strbuf, other._length, ch);
	_length = len;
}



Copied_Pointer::Copied_Pointer(char* str, int n)
{
	_strbuf = new char[n];
	strncpy(_strbuf, str,n);
	_length = n;

}


char Copied_Pointer::charAt(int index) const
{
	int len = length();
	if (index > len)
	{
		cout << "The index is greater then the length" << endl;
	}
	else
	{
		return _strbuf[index];
	}
}


int Copied_Pointer:: length() const
{
	return _length;

}
void Copied_Pointer :: reserve(int len)
{
	_strbuf = new char[len];

}

void Copied_Pointer:: append(char app)
{

	int len = length();

	_strbuf[len] = app;

	++_length;

}

void Copied_Pointer:: print()
{
	int len = length();
	for (int i = 0; i < len + 1; ++i)
	{
		cout << _strbuf[i];
	}
}

Copied_Pointer& Copied_Pointer ::operator= (Copied_Pointer& other)
{
	_strbuf = new char[other._length];
	strncpy(_strbuf, other._strbuf,other._length);

	this->_length = other._length;
	return *this;

}
