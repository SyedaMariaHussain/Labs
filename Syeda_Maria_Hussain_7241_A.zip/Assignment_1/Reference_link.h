#ifndef REFERNCE_LINK_H
#define REFERNCE_LINK_H

class Ref_link{

public:

	Ref_link(Ref_link* p = 0) : _strbuf(0)
	{
		Prev = Next = this;
	}
	


	~Ref_link();
	char charAt(int) const;   //returns the character at the passed index
	int length() const;                            //returns the length of the buffer
	void reserve(int);                             //allocates memory for the string, according to the passed character length
	void append(char);                          //appends a single character at the end
	void print();

	char* get();
	


	Ref_link(const Ref_link& r);
	


	Ref_link& operator= (const Ref_link &r);


	bool single();
	






private:
	//length of the string
	char*    _strbuf;
	int _length;

	Ref_link*   Prev;
	Ref_link*  Next;

	void acquire(const Ref_link& r)
	{ // insert this to the list
		_strbuf = r._strbuf;
		_length = r._length;
		Next = r.Next;
		Next->Prev = this;
		
		(const_cast<Ref_link*>(&r))->Next = this;
	}

	void del()
	{
		if (single())
			delete[] _strbuf;
		else
		{
			Prev->Next = Next;
			Next->Prev = Prev;
			Prev = Next = 0;

		}

	}

};

#endif