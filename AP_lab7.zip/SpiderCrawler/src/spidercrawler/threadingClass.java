/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spidercrawler;

import java.io.*;     
import java.util.*; 
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileOwnerAttributeView;
import java.nio.file.attribute.UserPrincipal;

/**
 *
 * @author Syeda Maria Hussain
 */
public class threadingClass extends Thread{
    
    String farig;
    static List<Rec> Files_Names = new ArrayList<Rec>();
    static List<Str> Files_2 = new ArrayList<Str>();
    static List<Attribute> Files_Attribute = new ArrayList<Attribute>();
    int start;
    File foo;
    int end;
    int op;
    
    threadingClass(List<Rec> Files,int range1, int range2,String far, int operation)
    {
        Files_Names = Files;
        start = range1;
        end = range2;
        farig = far;
        op = operation;
    }
    
    threadingClass(String far, List<Str> Files,int range1, int range2, int oper)
    {
        Files_2 = Files;
        start = range1;
        end = range2;
        farig = far;
        op = oper;
    }
    
    threadingClass(String far, int range1,List<Attribute> Files, int range2, int oper)
    {
        Files_Attribute = Files;
        start = range1;
        end = range2;
        farig = far;
        op = oper;
    }
    
    
    
    threadingClass(File F, String far,int oper)
    {
        farig = far;
        foo = F;
        op = oper;
    }
    
    
    public void run()
    {  
        System.out.println("Thread Running");
        int temp = 1;
        if(op == 1)
        {
            for (int i = start; i < end; i++)
            {
                Rec farig2 = Files_Names.get(i);
                if(farig2.FileN.equals(farig))
                {
                    System.out.println("File Found!");
                    System.out.println("Path is: " + farig2.FileP);
                    temp = 0;
                }

            }
        }
        else
        if(op == 2)
        {
            for (int i = start; i < end; i++)
            {
                Str farig2 = Files_2.get(i);
                if(farig2.FileS.contains(farig))
                {
                    System.out.println("File Found ");
                    System.out.println("Path is : " + farig2.FileP);
                    temp = 0;
                    break;
                }

            }
            
        }
        // check file on the basis of a string.
        if(op == 3)
        {
            try
            {
                Crawling(foo," ");
            }
            catch(IOException e)
            {
                System.out.println("Hello Exception :P");
            }
        }
        
        // For the Attributes of the file
        if(op == 4)
        {
            for (int i = start; i < end; i++)
            {
                Attribute attr = Files_Attribute.get(i);
                
                // For checking the number of sub folder in a directory.
               File dir;
                dir = new File(attr.FileP);
                int numberOfSubfolders = 0;
                File[] listDir;
                listDir =  attr.listFiles();
                for (int i = 0; i < listDir.length; i++) {
                    if (listDir[i].isDirectory()) {
                            numberOfSubfolders++;
                        }
                }
                
                if(attr.sub_folders ==  numberOfSubfolders)
                {
                    System.out.println("File Found ");
                    System.out.println("Path is : " + attr.FileP);
                    temp = 0;
                    break;
                }
                
                FileTime  creation_time = null;
                // For checking the creation date of a folder 
                 Path p = Paths.get(attr.FileP);
                try 
                {
                    BasicFileAttributes view = Files.getFileAttributeView(p, BasicFileAttributeView.class).readAttributes();
                    if(creation_time ==  view.creationTime())
                    {
                         System.out.println("File Found ");
                         System.out.println("Path is : " + attr.FileP);
                         temp = 0;
                          break;
                    }
                }
                catch (IOException ex) {
                    Logger.getLogger(threadingClass.class.getName()).log(Level.SEVERE, null, ex);
                }
                    
                     FileTime modified_time = null ;
                // For checking the modification date of a folder 
                 Path p1 = Paths.get(attr.FileP);
                try {
                    BasicFileAttributes view1 = Files.getFileAttributeView(p1, BasicFileAttributeView.class).readAttributes();
                    if(modified_time  == view1.creationTime())
                    {
                         System.out.println("File Found ");
                         System.out.println("Path is : " + attr.FileP);
                         temp = 0;
                          break;
                    }
                    
                    
              
                    
                } catch (IOException ex) {
                    Logger.getLogger(threadingClass.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                // for checking the owner of a folder 
                UserPrincipal owner = null;
                Path path = Paths.get(attr.FileP);
                FileOwnerAttributeView ownerAttributeView = Files.getFileAttributeView(path, FileOwnerAttributeView.class);
                try {
                    if (owner == ownerAttributeView.getOwner())
                    {
                         System.out.println("File Found ");
                         System.out.println("Path is : " + attr.FileP);
                         temp = 0;
                        System.out.println("owner: " + owner.getName());
                        break;
                    }
                } catch (IOException ex) {
                    Logger.getLogger(threadingClass.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            
                
                
                
                
                
            }
        
        
        
    }
    }
  
    
    public static  void Crawling(File f, String Farig3) throws IOException
    {

    	Rec temp;
    	temp = new Rec();
    	temp.FileN = f.getName();
    	temp.FileP = f.getAbsolutePath();
    	temp.FileS = (int) ((f.length())/1024);
    	
    	if(f.getName().endsWith(".txt") && f.isFile())
    	{
            int readlimiter = 0;

            FileInputStream buf1 = new FileInputStream(f.getAbsoluteFile());
    	    BufferedReader buf2 = new BufferedReader(new InputStreamReader(buf1));

    	    String farig4;

        	Str temp2 = null;
        	temp2 = new Str();
        	temp2.FileN = f.getName();
        	temp2.FileP = f.getPath();
        	temp2.FileS = "";
    	    while ((farig4 = buf2.readLine()) != null) 
            {
    	    	readlimiter++;
    	    	temp2.FileS = temp2.FileS + farig4;
    	    	if(readlimiter > 200)
    	    		break;
    	    }
    	    buf1.close();
    	    Files_2.add(temp2);
    	}
    	
    	
    	Files_Names.add(temp);
    	
    	if (f.isDirectory()) 
        {
        	File[] Heir = f.listFiles();
    		Farig3 += "    ";
    		SpiderCrawler[] threads = new SpiderCrawler[Heir.length];  
    		System.out.println(Heir.length);
        	for (int i = 0; i < Heir.length; i++) 
                {
                   
                    threadingClass t1 = new threadingClass(Heir[i], Farig3,3);
                    t1.start();
                    //Crawling(Heir[i], Farig3);
        	}
        }
    }
    
    
    
}
