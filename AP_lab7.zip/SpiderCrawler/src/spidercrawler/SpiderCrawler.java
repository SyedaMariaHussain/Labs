/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spidercrawler;

import java.io.*;     
import java.util.*;  
/**
 *
 * @author Syeda Maria Hussain
 */
public class SpiderCrawler {

    private  File F1;
    private  String str;
    
    
    
    
    
    static List<Rec> Files_ = new ArrayList<Rec>();
    static List<Str> Files_Names = new ArrayList<Str>();
     static List<Attribute> Files_N = new ArrayList<Attribute>();
	
    public SpiderCrawler(File f1, String str)
    {
            this.F1 = f1;
            this.str = str;		
    }
    SpiderCrawler()
    {

    }
	
    public static void main(String[] args) throws IOException 
    {
    	
    
        Scanner console = new Scanner(System.in);
        System.out.print("How are currently in Home Directort Enter the folder: ");
        String DName = console.nextLine();
        File f = new File(DName);
        threadingClass t1 = new threadingClass(f," ",3);
        t1.start();
        //Crawling(f,"");
        try{
             t1.join();
        }
        catch(InterruptedException IE)
        {
            System.out.println("Hello");
        }
        
        Files_ = t1.Files_Names;
        Files_Names = t1.Files_2;
        Files_N = t1.Files_N;
        
        System.out.println("He " + Files_Names.size());
        System.out.println(Files_.size());
        
        System.out.println("Type Name to Search by File Name: ");
        System.out.println("Type Content to Search by File Name: ");
        System.out.println("Type Attribute of File Name to search for file: ");
        
        String Choice = console.nextLine();
        
        if(Choice.equals("Name"))
        {
        	System.out.println("File to Search?: ");
        	String fileName = console.nextLine();
                Search_L(fileName);
        }
        if(Choice.equals("Content"))
        {
            System.out.println("Enter Text Content to search the File ");
        	String farig = console.nextLine();
        	Search_farig(farig);
        }
        
        if(Choice.equals("Attributes"))
        {
            System.out.println("Enter Text Content to search the File ");
        	String farig = console.nextLine();
        	Search_Attribute(farig);
        }
    }
    
    
    private static void Search_L(String fileName)
    {
    	int temp = 1;
        int size = Files_.size();
        threadingClass t1 = new threadingClass(Files_, 0, (int)Math.floor(size/3), fileName,1);
        threadingClass t2 = new threadingClass(Files_, (int)Math.floor(size/3), (int)Math.floor(2*size/3), fileName,1);
        threadingClass t3 = new threadingClass(Files_, (int)Math.floor(2* size/3), size, fileName,1);
        t1.start();
        t2.start();
        t3.start();
    }
    
    
    private static void Search_farig(String farig)
    {
        int temp = 1;
        int size = Files_Names.size();
        threadingClass t1 = new threadingClass(farig,Files_Names, 0, (int)Math.floor(size/3),2);
        threadingClass t2 = new threadingClass(farig,Files_Names, (int)Math.floor(size/3), (int)Math.floor(2*size/3),2);
        threadingClass t3 = new threadingClass(farig,Files_Names, (int)Math.floor(2* size/3), size,2);
        t1.start();
        t2.start();
        t3.start();
    }
    
     private static void Search_Attribute(String farig)
    {
        System.out.println("Type Size to Search by File Name: ");
        System.out.println("Type Creation Date to Search by File Name: ");
        System.out.println("Type Modification Date of File Name to search for file: ");
        System.out.println("Type Owner of File Name to search for file: ");
        Scanner console = new Scanner(System.in);
        String Choice = console.nextLine();
        
        
        
        if(Choice.equals("Size"))
        {
        	 
        int temp = 1;
        int size = Files_Names.size();
        threadingClass t1 = new threadingClass(farig,Files_Names, 0, (int)Math.floor(size/3),4);
        threadingClass t2 = new threadingClass(farig,Files_Names, (int)Math.floor(size/3), (int)Math.floor(2*size/3),4);
        threadingClass t3 = new threadingClass(farig,Files_Names, (int)Math.floor(2* size/3), size,4);
        t1.start();
        t2.start();
        t3.start();
        }
        if(Choice.equals("Creation Date"))
        {
             
        int temp = 1;
        int size = Files_Names.size();
        threadingClass t1 = new threadingClass(farig,Files_Names, 0, (int)Math.floor(size/3),4);
        threadingClass t2 = new threadingClass(farig,Files_Names, (int)Math.floor(size/3), (int)Math.floor(2*size/3),4);
        threadingClass t3 = new threadingClass(farig,Files_Names, (int)Math.floor(2* size/3), size,4);
        t1.start();
        t2.start();
        t3.start();
        }
        
        if(Choice.equals("Modification Date"))
        {
            int temp = 1;
        int size = Files_Names.size();
        threadingClass t1 = new threadingClass(farig,Files_Names, 0, (int)Math.floor(size/3),4);
        threadingClass t2 = new threadingClass(farig,Files_Names, (int)Math.floor(size/3), (int)Math.floor(2*size/3),4);
        threadingClass t3 = new threadingClass(farig,Files_Names, (int)Math.floor(2* size/3), size,4);
        t1.start();
        t2.start();
        t3.start();
        }
        
       
    }
 
    
    
    
    
}
