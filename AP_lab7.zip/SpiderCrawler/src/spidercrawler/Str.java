/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spidercrawler;
import java.io.*;     
import java.util.*; 
/**
 *
 * @author Syeda Maria Hussain
 */
public class Str {
    
    public String FileN;
    public String FileP;
	public String FileS;
    
    
    
}
