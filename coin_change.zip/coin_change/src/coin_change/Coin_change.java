/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coin_change;

import static java.lang.Double.POSITIVE_INFINITY;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Syeda Maria Hussain
 */
public class Coin_change {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       int[] dimes = {1,5,10,25};
       int randomNum;
       greedy_change(dimes ,51 );
       for (int i =0;i<10;i++)
       {
       randomNum = 1 + (int)(Math.random() * 1000);
        
        System.out.println("By Dynamic Programming " + dynamic_change(dimes,5, randomNum));
       }

    }
    
    
    // function for greedy coin change.
    
     public static Integer greedy_change(int[] dimes,int money ) {
            int coins = 0;
            int num25 = 0;
            int num5 = 0;
            int num10 = 0;
            int num1 = 0;
        switch (money) {
            case 1:
                System.out.print("Minimum number of coin is 1");
                return 1;
            case 5:
                System.out.print("Minimum number of coin is 5");
                return 5;
            case 10:
                System.out.print("Minimum number of coin is 10");
                return 10;
            case 25:
                System.out.print("Minimum number of coin is 25");
                return 25;
            default:
                while( money >= 25)
                {
                    coins ++;
                    num25++;
                    money = money - 25;
                    
                    
                }
                
                while( money >= 10)
                {
                    coins ++;
                    num10++;
                    money = money - 10;
                }
                while( money >= 5)
                {
                    coins ++;
                    num5++;
                    money = money - 5;
                }
                while( money >= 1)
                {
                    coins ++;
                    num1++;
                    money = money - 1;
                }
                
                System.out.println("Minimum number of coin is :" + coins);
                System.out.println("Number of 25 coin :" + num25);
                System.out.println("Number of 10 coin :" + num10);
                System.out.println("Number of 5 coin :" + num5);
                System.out.println("Number of 1 coin :" + num1);
                return coins;
        }
   
}
      // function for dynamic coin change problem;
        public static int dynamic_change(int [] dimes ,int size, int k )
        {
            int[] table = new int[k+1];
            if(k == 0)
                table[0] = 0;
             for (int i=1; i<=k; i++)
             {
                 table[i] = 100000;
             }
             
            
	for (int i=1; i<=k; i++)
    {
        // Go through all coins smaller than i
        for (int j=0; j< dimes.length; j++)
          if (dimes[j] <= i)
          {
              int sub_res = table[i-dimes[j]];
              if (sub_res != -1 && sub_res + 1 < table[i])
                  table[i] = sub_res + 1;
          }
         
    }
        
   return table[k];
        }
        
}
    

