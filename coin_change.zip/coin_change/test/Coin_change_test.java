/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import static coin_change.Coin_change.dynamic_change;
import static coin_change.Coin_change.greedy_change;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Syeda Maria Hussain
 */
public class Coin_change_test {
    int check_greedy;
    public Coin_change_test() {
         
   
    }
    check_greedy = greedy_change(dimes ,25 );
    if(check_greedy == 25)
   System.out.println("Test Successful.");
   check_dynamic = dynamic_change(dimes,5, 51)
           if(check_dynamic > 4)
            System.out.println("Test UnSuccessful.");
            else
            System.out.println("Test UnSuccessful.");  
    
}
