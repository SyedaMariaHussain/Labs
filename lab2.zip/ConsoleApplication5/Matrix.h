#ifndef MATRIX_H
#define MATRIX_H

#include<iostream>
#include<time.h>
#include <vector>
#include <iterator> 
#include <iomanip> 
#include <math.h>

using namespace std;


///// Class for Simple multiplication.......
class S_Mat
{
public:
	vector<vector<int> > matrixA;
	vector<vector<int> > matrixB;
	vector<vector<int> > matrixC;



	void init_mat()
	{
		// Matrix A...
		for (int i = 0; i < 1000; ++i) {
			matrixA.push_back(vector<int>());
		}

		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < matrixA.size(); j++) {
				matrixA[i].push_back((rand() % 10) + 1);
			}
		}

		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < 1000; j++) {
				cout << setw(4) << matrixA[i][j];
			}
			cout << endl;
		}


		// Matrix B...
		for (int i = 0; i < 1000; ++i) {
			matrixB.push_back(vector<int>());
		}

		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < matrixB.size(); j++) {
				matrixB[i].push_back((rand() % 10) + 1);
			}
		}


		cout << endl;
		cout << endl;

		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < 1000; j++) {
				cout << setw(4) << matrixB[i][j];
			}
			cout << endl;
		}



	}

	void S_Mat::Add()
	{



		// Matrix Addition....

		cout << endl;
		cout << endl;
		cout << "/////////********Addition of two vectors********///////////" << endl;
		for (int i = 0; i < 1000; ++i) {
			matrixC.push_back(vector<int>());
		}

		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < matrixC.size(); j++) {
				matrixC[i].push_back((matrixA[i][j] + matrixB[i][j]));
				cout << setw(4) << matrixC[i][j];
			}
			cout << endl;
		}


	}

	void S_Mat::Sub()
	{



		// Matrix Subtraction....

		cout << endl;
		cout << endl;
		cout << "/////////********Subtraction of two vectors********///////////" << endl;
		int a = 0;
		for (int i = 0; i < 1000; ++i) {
			matrixC.push_back(vector<int>());
		}
		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < matrixC.size(); j++) {
				a = (matrixA[i][j] - matrixB[i][j]);
				matrixC[i].push_back(a);

			}

		}
		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < 1000; j++) {
				cout << setw(4) << matrixC[i][j];
			}
			cout << endl;
		}


	}



	void Mul()
	{

		cout << endl;
		cout << endl;
		cout << "/////********* Multipilcation of Matrices***********//////////" << endl;
		// Matrix multipication logic
		for (int a = 0; a < 1000; a++)
		{
			for (int b = 0; b < 1000; b++)
			{
				matrixC[a].push_back(0);
				for (int c = 0; c < 1000; c++)
				{
					matrixC[a].push_back((matrixC[a][b] += matrixA[a][b] * matrixB[b][c]));
				}
			}
		}

		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < 1000; j++) {
				cout << setw(4) << matrixC[i][j];
			}
			cout << endl;
		}

	}

};


///// Class for strassen Multiplication......

class Strassen
{
public:
	vector<vector<int> > matrixA;
	vector<vector<int> > matrixB;
	vector<vector<int> > matrixC;

	// Sub Matrices.....

	vector<vector<int> > a11;
	vector<vector<int> > a12;
	vector<vector<int> > b11;
	vector<vector<int> > b12;
	vector<vector<int> > a21;
	vector<vector<int> > a22;
	vector<vector<int> > b21;
	vector<vector<int> > b22;

	//// Matrices C1,C2,C3, C4
	vector<vector<int> > C1;
	vector<vector<int> > C2;
	vector<vector<int> > C3;
	vector<vector<int> > C4;


	// Matrices P1, ...., P7

	vector<vector<int> > P1;
	vector<vector<int> > P2;
	vector<vector<int> > P3;
	vector<vector<int> > P4;
	vector<vector<int> > P5;
	vector<vector<int> > P6;
	vector<vector<int> > P7;

	// Matrices for temporary results...

	vector<vector<int> > aResult;
	vector<vector<int> > bResult;



	int n;


	//function for initiallizing the matrices......
	void init_mat()
	{
		// Matrix A...
		for (int i = 0; i < 1000; ++i) {
			matrixA.push_back(vector<int>());
		}

		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < matrixA.size(); j++) {
				matrixA[i].push_back((rand() % 10) + 1);
			}
		}

		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < matrixA.size(); j++) {
				cout << " "  << matrixA[i][j];
			}
			cout << endl;
		}


		// Matrix B...
		for (int i = 0; i < 1000; ++i) {
			matrixB.push_back(vector<int>());
		}

		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < matrixB.size(); j++) {
				matrixB[i].push_back((rand() % 10) + 1);
			}
		}


		cout << endl;
		cout << endl;

		for (int i = 0; i < 1000; i++) {
			for (int j = 0; j < matrixB.size(); j++) {
				cout <<" "<<  matrixB[i][j];
			}
			cout << endl;
		}
	

		n = ceil((matrixA.size()) / 2);

		///*********** sub matrices*******//////

		for (int i = 0; i < n; ++i) {
			a11.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < a11.size(); j++) {
				a11[i].push_back(0);
			}
		}
		///

		for (int i = 0; i < n; ++i) {
			a12.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < a12.size(); j++) {
				a12[i].push_back(0);
			}
		}

		////
		for (int i = 0; i < n; ++i) {
			a21.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < a21.size(); j++) {
				a21[i].push_back(0);
			}
		}
		////

		for (int i = 0; i < n; ++i) {
			a22.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < a22.size(); j++) {
				a22[i].push_back(0);
			}
		}
		//

		for (int i = 0; i < n; ++i) {
			b11.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < b11.size(); j++) {
				b11[i].push_back(0);
			}
		}

		////
		for (int i = 0; i < n; ++i) {
			b12.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < b12.size(); j++) {
				b12[i].push_back(0);
			}
		}
		////

		for (int i = 0; i < n; ++i) {
			b22.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < b22.size(); j++) {
				b22[i].push_back(0);
			}
		}
		///// bresult..
		for (int i = 0; i < n; ++i) {
			bResult.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < bResult.size(); j++) {
				bResult[i].push_back(0);
			}
		}

		///a result matrix////
		for (int i = 0; i < n; ++i) {
			aResult.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < bResult.size(); j++) {
				aResult[i].push_back(0);
			}
		}
		////// P1... P7



		for (int i = 0; i < n; ++i) {
			P1.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < P1.size(); j++) {
				P1[i].push_back(0);
			}
		}


		for (int i = 0; i < n; ++i) {
			P2.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < P2.size(); j++) {
				P2[i].push_back(0);
			}
		}


		for (int i = 0; i < n; ++i) {
			P3.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < P3.size(); j++) {
				P3[i].push_back(0);
			}
		}


		for (int i = 0; i < n; ++i) {
			P4.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < P4.size(); j++) {
				P4[i].push_back(0);
			}
		}


		for (int i = 0; i < n; ++i) {
			P5.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < P5.size(); j++) {
				P5[i].push_back(0);
			}
		}


		for (int i = 0; i < n; ++i) {
			P6.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < P6.size(); j++) {
				P6[i].push_back(0);
			}
		}


		for (int i = 0; i < n; ++i) {
			P7.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < P7.size(); j++) {
				P7[i].push_back(0);
			}
		}
		///c1,...c4

		for (int i = 0; i < n; ++i) {
			C1.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < C1.size(); j++) {
				C1[i].push_back(0);
			}
		}


		for (int i = 0; i < n; ++i) {
			C2.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < C2.size(); j++) {
				C2[i].push_back(0);
			}
		}


		for (int i = 0; i < n; ++i) {
			C3.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < C3.size(); j++) {
				C3[i].push_back(0);
			}
		}


		for (int i = 0; i < n; ++i) {
			C4.push_back(vector<int>());
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < C4.size(); j++) {
				C4[i].push_back(0);
			}
		}
		////


		for (int i = 0; i <1000; ++i) {
			matrixC.push_back(vector<int>());
		}

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < matrixC.size(); j++) {
				matrixC[i].push_back(0);
			}
		}
	}


	// strassen algorithm...
	void strassen(vector<vector<int>> a, vector<vector<int>>b, vector<vector<int>>c ,int na)
	{
		///// initiallizing vector C with 0...
		for (int i = 0; i < a.size(); ++i) {
			c.push_back(vector<int>());
		}

		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < a.size(); j++) {
				c[i].push_back(0);
			}
		}
		///////// If the size of the matrices is 1x1.......
		
		if (n == 1)
		{
			c[0].push_back(a[0][0]*b[0][0]);
			return ;
		}
		else
		{

			for (int i = 0; i < na; i++) {
				for (int j = 0; j < na; j++) {
					a11[i].push_back( a[i][j]);
					a12[i].push_back(a[i][j+n]);
					a21[i].push_back(a[i+n][j]);
					a22[i].push_back(a[i+n][j+n]);

					/// sub matrices for matrix B
					b11[i].push_back(b[i][j]);
					b12[i].push_back(b[i][j + n]);
					b21[i].push_back(b[i + n][j]);
					b22[i].push_back(b[i + n][j + n]);
					

					
				}
			}


			// Calculating p1 to p7:

			sum(a11, a22, aResult, na); // a11 + a22
			sum(b11, b22, bResult, na); // b11 + b22
			strassen(aResult, bResult, P1, na); // p1 = (a11+a22) * (b11+b22)

			sum(a21, a22, aResult, na); // a21 + a22
			strassen(aResult, b11, P2, na); // p2 = (a21+a22) * (b11)

			sub(b12, b22, bResult, na); // b12 - b22
			strassen(a11, bResult, P3, na); // p3 = (a11) * (b12 - b22)

			sub(b21, b11, bResult, na); // b21 - b11
			strassen(a22, bResult, P4, na); // p4 = (a22) * (b21 - b11)

			sum(a11, a12, aResult, na); // a11 + a12
			strassen(aResult, b22, P5, na); // p5 = (a11+a12) * (b22)	

			sub(a21, a11, aResult, na); // a21 - a11
			sum(b11, b12, bResult, na); // b11 + b12
			strassen(aResult, bResult, P6, na); // p6 = (a21-a11) * (b11+b12)

			sub(a12, a22, aResult, na); // a12 - a22
			sum(b21, b22, bResult, na); // b21 + b22
			strassen(aResult, bResult, P7, na); // p7


			// calculating c21, c21, c11 e c22:

			sum(P3, P5, C1, na); // c12 = p3 + p5
			sum(P2, P4, C2, na); // c21 = p2 + p4

			sum(P1, P4, aResult, na); // p1 + p4
			sum(aResult, P7, bResult, na); // p1 + p4 + p7
			sub(bResult, P5, C3, na); // c11 = p1 + p4 - p5 + p7

			sum(P1, P3, aResult, na); // p1 + p3
			sum(aResult, P6, bResult, na); // p1 + p3 + p6
			sub(bResult, P2, C4, na); // c22 = p1 + p3 - p2 + p6
			

			// Grouping the results obtained in a single matrix:
			for (int i = 0; i < na; i++) {
				for (int j = 0; j < na; j++) {
					c[i][j] = C3[i][j];
					c[i][j + na] = C1[i][j];
					c[i + na][j] = C2[i][j];
					c[i + na][j + na] = C4[i][j];
				}
			}





		}
		
	}

	//function for sum of sub matrices....
	void sum(vector<vector<int>>a, vector<vector<int>>b, vector<vector<int>>c,int nam)
	{
		for (int i = 0; i < nam; i++) {
			for (int j = 0; j < nam; j++) {
				c[i].push_back((a[i][j] + b[i][j]));
				
			}
			
		}
   	}

	//function for subtraction of sub matrices....
	void sub(vector<vector<int>>a, vector<vector<int>>b, vector<vector<int>>c, int nam)
	{
		for (int i = 0; i < nam; i++) {
			for (int j = 0; j < nam; j++) {
				c[i].push_back((a[i][j] + b[i][j]));

			}

		}
	}


	void s_mul()
	{
		strassen(matrixA,matrixB,matrixC,n);
		

	}



};





#endif