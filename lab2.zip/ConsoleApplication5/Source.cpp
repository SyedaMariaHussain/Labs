#include<iostream>
#include<time.h>
#include <vector>
#include <iterator> 
#include <iomanip> 
#include <math.h>
#include "Matrix.h"

using namespace std;

int main()
{
	S_Mat mat;
	mat.init_mat();

	mat.Mul();

	system("pause");
	return 0;

}